Mission Modul "Crash Site"
Author: Alex31535 (alex31535@miegelke.de)
Version: 0.2 (Beta)
Description: Creation of an accident site of a random vehicle with an injured crew for the purpose of evacuation


installation:
- The mission folder "crash_site" must be in the root directory
- create a file "initPlayerServer.sqf" in the root directory and set the following entry:

  [mission_activator, ["<t color='#00ff40'>Crash Site</t>",{[_this,"crash_site\crash_site_init.sqf"] remoteexec ["execvm",2]},"",1.5,true,true,"","",2]] remoteExec ["addAction",_this select 0,mission_activator];

- create an object with the name "mission_activator" using the editor (or script)
finished!


Usage:
A new mission is activated with the "mission_activator" object via the action entry "Crash Site".
As soon as a mission setup has been completed, it will be announced via a screen text.
To accomplish the mission, the accident vehicle and the surviving crew members must be found within the area marked on the map
be brought far from the crash zone. the mission fails when enemy units have eliminated the survivors.
After completing the mission (or failure), the mission can be called again - this time with new, random parameters.
Configurable random parameters for creating a mission are documented within "crash_site_init.sqf".
To test new parameters, a debug mode can be activated, which shows placements and enemy movements (this mode is automatically deactivated on dedicated servers).

Known Issues:
- In rare cases it can happen that road blocks are too close to each other due to the environmental preferences
